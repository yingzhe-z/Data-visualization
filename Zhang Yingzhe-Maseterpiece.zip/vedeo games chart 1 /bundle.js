(function (d3$1) {
  'use strict';

  const svg = d3$1.select('svg');

  const height = +svg.attr('height');
  const width = +svg.attr('width');
  const margin = {top: 40, right: 80, bottom: 40, left: 40};
  const innerRadius = 20;
  const chartWidth = width - margin.left - margin.right;
  const chartHeight = height - margin.top - margin.bottom;
  const outerRadius = (Math.min(chartWidth, chartHeight) / 2);
  const g = svg.append("g").attr("transform", `translate(${width / 2}, ${height / 2})`);

  const angle = d3.scaleLinear()
    .range([0, 2 * Math.PI]);

  const radius = d3.scaleLinear()
    .range([innerRadius, outerRadius]);

  const x = d3.scaleBand()
    .range([0, 2 * Math.PI])
    .align(0);

  const y = d3.scaleLinear()
    .range([innerRadius, outerRadius]);

  const z = d3.scaleOrdinal()
    .range(["#FFC0CB"]);

  const render = data => {
    x.domain(data.map(d => d.angle));
    y.domain([0, d3$1.max(data, d => d.total)]);
    z.domain(data.columns.slice(1));

    //Extend the domain slightly to match the range of [0, 2pi].
    const angleOffset = -360.0/data.length/2.0;
    angle.domain([0, d3$1.max(data, (d, i) => i + 1)]);
    radius.domain([0, d3$1.max(data, d => d.y0 + d.y)]);
    
    g.append('g')
      .selectAll('g')
      .data(d3.stack().keys(data.columns.slice(1))(data))
      .enter().append('g')
      .attr('fill', d => z(d.key))
      .selectAll('path')
      .data(d => d)
      .enter().append('path')
      .attr('d', d3.arc()
            .innerRadius(d => y(d[0]))
            .outerRadius(d => y(d[1]))
            .startAngle(d => x(d.data.angle))
            .endAngle(d => x(d.data.angle) + x.bandwidth())
            .padAngle(0.01)
            .padRadius(innerRadius)
           )
      .attr("trasnform", `rotate(${angleOffset})`);
    
    const label = g.append('g')
      .selectAll('g')
      .data(data)
      .enter().append('g')
      .attr('text-anchor', 'middle')
      .attr('transform', d => `rotate(${((x(d.angle) + x.bandwidth() / 2) * 180 / Math.PI - (90 - angleOffset))}) translate(${outerRadius + 30}, 0)`);
    
    label.append('text')
      .attr('transform', function(d) { return (x(d.angle) + x.bandwidth() / 2 + Math.PI / 2) % (2 * Math.PI) < Math.PI ? "rotate(90)translate(0,16)" : "rotate(-90)translate(0,-9)"; })
      .text(d => d.angle)
      .style("font-size", 14);
    
    g.selectAll(".axis")
      .data(d3.range(angle.domain()[1]))
      .enter().append('g')
      .attr("class", "axis")
      .attr("transform", d => `rotate(${angle(d) * 180 / Math.PI})`)
      .call(d3$1.axisLeft()
            .scale(radius.copy().range([-innerRadius, -outerRadius - 10])));
    
    const yAxis = g.append('g')
      .attr('text-anchor', 'middle');
    
    const yTick = yAxis
    	.selectAll('g')
      .data(y.ticks(5).slice(1))
      .enter().append('g');
    
    yTick.append('circle')
      .attr("fill", "none")
      .attr("stroke", "gray")
      .attr("stroke-dasharray", "4,4")
      .attr("r", y);
    
    yTick.append('text')
      .attr('y', d => -y(d))
      .attr('dy', "-0.35em")
      .attr('x', () => -10)
      .text(y.tickFormat(5, 's'))
      .style("font-size", 14);
    
    const legend = g.append('g')
      .selectAll('g')
      .data(data.columns.slice(1).reverse())
      .enter().append("g")
      .attr("transform", (d, i) => `translate(${outerRadius + 100}, ${-outerRadius + 100 + (i - (data.columns.length - 1)/2) * 20})`);
    
    legend.append('rect')
      .attr('width', 18)
      .attr('height', 18)
      .attr('fill', z);

    legend.append('text')
      .attr('x', 24)
      .attr('y', 9)
      .attr('dy', "0.35em")
      .text(d => d)
      .style('font-size', 12);
  };
            
  d3.csv("data.csv", (d, i, columns) => {
      for (var i = 1, t = 0; i < columns.length; ++i) t += d[columns[i]] = +d[columns[i]];
      d.total = t;
      return d;
      }).then(data => render(data));

}(d3));
