(function (d3) {
  'use strict';

  const svg = d3.select("svg");

  const width= +svg.attr("width");
  const height= +svg.attr("height");


  const xValue=  d=> d.pagecount;
  const yValue= d=> d.Title;
  const margin = {top: 50, right: 30, bottom: 70, left: 490};
  const innerWidth = width- (margin.left+ margin.right);
  const innerHeight = height- (margin.top+ margin.bottom);

  const render=data => {
    const xScale = d3.scaleLinear()
    							.domain([0, d3.max(data,xValue)])
    							.range([0, innerWidth]);
    
    const yScale = d3.scaleBand()
    							 .domain(data.map(yValue))
    							 .range([0, innerHeight])
    							 .padding(0.15);
    
    const xAxisTickFormat = number => 
    			d3.format('3.0s')(number);
    
    const yAxis = d3.axisLeft(yScale);
    const xAxis= d3.axisBottom(xScale)
    					  	.tickFormat(xAxisTickFormat)
    							.tickSize(-innerHeight+margin.top);
    
    
    
    const g = svg.append("g")
    					.attr("transform" , `translate(${margin.left}, ${margin.top})`);
    
    g.append("text"). text( "page count")
      							.attr("x", innerWidth/6).attr("y", "-8").attr("class", "title");
    
    g.append("g").call(yAxis)
    			.selectAll(".domain , .tick line").remove();//or may use .call(yAxis) at the end to do the same thing
   const xAxisGroup= g.append("g").call(xAxis) 
             			.attr("transform" , `translate(0, ${innerHeight})`);
    		 xAxisGroup.append("text").text("Page Count")
      						.attr("x", innerWidth/2).attr("y",margin.bottom/1.2)
    							.attr("class", "xLabel");
        xAxisGroup.select('.domain, .tick line').remove();
        


  	g.selectAll("rect").data(data)
      .enter().append("rect")
    	.attr("y", d=> yScale(yValue(d)) )
    	.attr("width", d => xScale(xValue(d)))
      .attr("height", yScale.bandwidth());
  };

  d3.csv("data.csv").then(data => {
    data.forEach(d => {
      d.pagecount= +d.pagecount;  
    });
    render(data);
  });

}(d3));
